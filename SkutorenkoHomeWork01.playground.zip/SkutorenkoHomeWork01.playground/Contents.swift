//: Playground - noun: a place where people can play

import UIKit

let name = "Иванов"
let surname = "Иван"
let patronymic = "Иванович"
let height = 177
let weight = 82

print("ФИО:", name, surname, patronymic, "рост", String(height), "вес", String(weight))
